require "rails_helper"

RSpec.describe InvoiceMailer, type: :mailer do
end
