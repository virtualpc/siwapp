class Estimate < Common

end
