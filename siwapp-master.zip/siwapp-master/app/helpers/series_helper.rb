module SeriesHelper
end
