# RailsSettings Model
class Settings < RailsSettings::CachedSettings
end
