Settings.defaults[:currency] = :eur
Settings.defaults[:days_to_due] = 0

